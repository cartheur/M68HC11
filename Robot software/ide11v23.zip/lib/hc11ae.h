;============================================================================;
; FILE: HC11AE.H
; FUNC: REGISTER ASSIGNMENTS FOR 68HC11A8/A1/A0/E9/E1/E0 & 68HC811E2
;============================================================================;

REGBAS  EQU     $1000

PORTA   EQU     REGBAS + $00
PIOC    EQU     REGBAS + $02
PORTC   EQU     REGBAS + $03
PORTB   EQU     REGBAS + $04
PORTCL  EQU     REGBAS + $05
DDRC    EQU     REGBAS + $07
PORTD   EQU     REGBAS + $08
DDRD    EQU     REGBAS + $09
PORTE   EQU     REGBAS + $0A
CFORC   EQU     REGBAS + $0B
OC1M    EQU     REGBAS + $0C
OC1D    EQU     REGBAS + $0D
TCNT    EQU     REGBAS + $0E
TIC1	EQU     REGBAS + $10
TIC2	EQU	REGBAS + $12
TIC3	EQU	REGBAS + $14
TOC1	EQU	REGBAS + $16
TOC2	EQU	REGBAS + $18
TOC3	EQU	REGBAS + $1A
TOC4	EQU	REGBAS + $1C
TOC5	EQU	REGBAS + $1E	; HC11A8/A1/A0 & HC811E2 only
TI4O5	EQU	REGBAS + $1E	; HC11E9/E1/E0 only
TCTL1   EQU     REGBAS + $20
TCTL2   EQU     REGBAS + $21
TMSK1   EQU     REGBAS + $22
TFLG1   EQU     REGBAS + $23
TMSK2   EQU     REGBAS + $24
TFLG2   EQU     REGBAS + $25
PACTL   EQU     REGBAS + $26
PACNT   EQU     REGBAS + $27
SPCR    EQU     REGBAS + $28
SPSR    EQU     REGBAS + $29
SPDR    EQU     REGBAS + $2A
BAUD    EQU     REGBAS + $2B
SCCR1   EQU     REGBAS + $2C
SCCR2   EQU     REGBAS + $2D
SCSR    EQU     REGBAS + $2E
SCDR    EQU     REGBAS + $2F
ADCTL   EQU     REGBAS + $30
ADR1    EQU     REGBAS + $31
ADR2    EQU     REGBAS + $32
ADR3    EQU     REGBAS + $33
ADR4    EQU     REGBAS + $34
BPROT   EQU	REGBAS + $35	; HC11E9/E1/E0 & HC811E2 only
OPTION  EQU     REGBAS + $39
COPRST  EQU     REGBAS + $3A
PPROG   EQU     REGBAS + $3B
HPRIO   EQU     REGBAS + $3C
INIT    EQU     REGBAS + $3D
TEST1   EQU     REGBAS + $3E
CONFIG  EQU     REGBAS + $3F

xPORTA   EQU      $00
xPIOC    EQU      $02
xPORTC   EQU      $03
xPORTB   EQU      $04
xPORTCL  EQU      $05
xDDRC    EQU      $07
xPORTD   EQU      $08
xDDRD    EQU      $09
xPORTE   EQU      $0A
xCFORC   EQU      $0B
xOC1M    EQU      $0C
xOC1D    EQU      $0D
xTCNT    EQU      $0E
xTIC1	 EQU      $10
xTIC2	 EQU	  $12
xTIC3	 EQU	  $14
xTOC1	 EQU	  $16
xTOC2	 EQU	  $18
xTOC3	 EQU	  $1A
xTOC4	 EQU	  $1C
xTOC5	 EQU	  $1E	; HC11A8/A1/A0 & HC811E2 only
xTI4O5	 EQU	  $1E	; HC11E9/E1/E0 only
xTCTL1   EQU      $20
xTCTL2   EQU      $21
xTMSK1   EQU      $22
xTFLG1   EQU      $23
xTMSK2   EQU      $24
xTFLG2   EQU      $25
xPACTL   EQU      $26
xPACNT   EQU      $27
xSPCR    EQU      $28
xSPSR    EQU      $29
xSPDR    EQU      $2A
xBAUD    EQU      $2B
xSCCR1   EQU      $2C
xSCCR2   EQU      $2D
xSCSR    EQU      $2E
xSCDR    EQU      $2F
xADCTL   EQU      $30
xADR1    EQU      $31
xADR2    EQU      $32
xADR3    EQU      $33
xADR4    EQU      $34
xBPROT   EQU      $35	; HC11E9/E1/E0 & HC811E2 only
xOPTION  EQU      $39
xCOPRST  EQU      $3A
xPPROG   EQU      $3B
xHPRIO   EQU      $3C
xINIT    EQU      $3D
xTEST1   EQU      $3E
xCONFIG  EQU      $3F
