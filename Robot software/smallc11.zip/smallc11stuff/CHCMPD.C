
/* change string "cmpd" to "cpd" for asmhc11.exe 01-06-88 - hm */

#include <stdio.h>

main()
{
	int c;
	int state = 0;

	fprintf(stderr,"\n'cmpd' to 'cpd' changer for asmhc11.exe  01-06-88 -hm\n");
	while((c = fgetchar()) != EOF)
	{
		switch(state)
		{
			case 0:
			if(c == 'c')
				state++;
			else
				fputchar(c);
			break;

			case 1:
                        if(c == 'm')
				state++;
			else
			{
				state = 0;
				fputchar('c');
				fputchar(c);
			}
                        break;

			case 2:
			if(c == 'p')
				state++;
			else
			{
				state = 0;
				fputchar('c');
				fputchar('m');
				fputchar(c);
			}
			break;

                        case 3:
			if(c == 'd')
			{
				fputchar('c');
				fputchar('p');
				fputchar('d');
			}
			else
			{
				fputchar('c');
				fputchar('m');
				fputchar('p');
				fputchar(c);
			}
			state = 0;
			break;
		}
	}
}