/*
** Small-C Compiler Version 2.0
**
** Copyright 1982 J. E. Hendrix
**
** Part 3
*/
#include	<stdio.h>
#include	"ccdef.c"


/*
** external references in part 1
*/
extern char
  stage[STAGESIZE],
  litq[LITABSZ],
 *glbptr, *lptr,  ssname[NAMESIZE],  quote[2], *stagenext;

extern int
  ch,  csp,  litlab,  litptr,  nch,  op[16],  op2[16],
  (*oper)(),  opindex,	opsize;

extern int
	xor(), and(), eq(),
	ne(), le(), ge(), lt(), gt(),
	asr(), asl(), add(), sub(),
	mult(), div(), mod(), or(),
	ule(), uge(), inc(), dec(),
	ult(), ugt(),
	le0(), lt0(),
	gt0(), ge0(), ult0(),
	eq0(), ne0();

#include	"cc31.c"
#include	"cc32.c"
#include	"cc33.c"
