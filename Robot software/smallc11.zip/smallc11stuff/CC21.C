junk()	{
  if(an(inbyte())) while(an(ch))  gch();
  else while(an(ch)==0) {
     if(ch==0)break;
     gch();
     }
  blanks();
  }

endst()  {
blanks();
return ((streq(lptr,";")|(ch==0)));
}

needtoken(str)	char *str;  {
   if (match(str)==0) error("missing token");
   }

findglb(sname)	char *sname; {
   cptr=STARTGLB;
   while(cptr < glbptr)  {
      if(astreq(sname,cptr+NAME,NAMEMAX)) return(cptr);
      cptr=nextsym(cptr);
      }
   return 0;
   }

findloc(sname)
char *sname;
{

cptr= locptr - 1; /* search backward for block locals */
while(cptr > STARTLOC)	{
     cptr = cptr - *cptr;
     if(astreq(sname,cptr,NAMEMAX)) return (cptr - NAME);
     cptr = cptr - NAME - 1;
     }
return NO;
}

addsym(sname, id, typ, value, lgptrptr, class)
char	*sname;
int	id, typ, value, *lgptrptr, class;
{

  if(lgptrptr == &glbptr) {
    if(cptr2=findglb(sname)) return cptr2;
    if(glbptr >= ENDGLB) {
      error("global symbol table overflow");
      return NO;
      }
    cptr= *lgptrptr;
    }
  else {
    if(locptr > (ENDLOC-SYMMAX)) {
      printf("**** SMALL-C: local symbol table overflow ****\n");
      exit(-1);
      }
    cptr= *lgptrptr;
    }
  cptr[IDENT]=id;
  cptr[TYPE]=typ;
  cptr[CLASS]=class;
  putint(value, cptr+OFFSET, OFFSIZE);
  cptr3 = cptr2 = cptr + NAME;
  while(an(*sname)) *cptr2++ = *sname++;
  *cptr2 = cptr2 - cptr3;	  /* set length */
  *lgptrptr = ++cptr2;
  return cptr;
  }

nextsym(zentry) char *zentry; {
  zentry = zentry + NAME;
  while(*zentry++ >= ' '); /* find length byte */
  return zentry;
  }

/*
** get integer of length len from address addr
** (byte sequence set by "putint")
*/
getint(addr, len) char *addr; int len; {
  int i;
  i = *(addr + --len);	/* high order byte sign extended */
  while(len--) i = (i << 8) | *(addr+len)&255;
  return i;
  }

/*
** put integer i of length len into address addr
** (low byte first)
*/
putint(i, addr, len) char *addr; int i, len; {
  while(len--) {
    *addr++ = i;
    i = i>>8;
    }
  }

/*
** test if next input string is legal symbol name
*/
symname(sname, ucase) char *sname; int ucase; {
  int k;char c;
  blanks();
  if(alpha(ch)==0) return 0;
  k=0;
  while(an(ch)) {
      sname[k]=gch();
    if(k<NAMEMAX) ++k;
    }
  sname[k]=0;
  return 1;
  }


addwhile(ptr)  int ptr[]; {
  int k;
  ptr[WQSP]=csp;	   /* and stk ptr */
  ptr[WQLOOP]=getlabel();  /* and looping label */
  ptr[WQEXIT]=getlabel();   /* and exit label */
  if (wqptr==WQMAX) {
    printf("**** SMALL-C: too many active loops ****\n");
    exit(-1);
    }
  k=0;
  while (k<WQSIZ) *wqptr++ = ptr[k++];
  }

delwhile() {
  if(readwhile()) wqptr=wqptr-WQSIZ;
  }

readwhile() {
  if (wqptr==wq) {
    error("no active loops");
    return 0;
    }
  else return (wqptr-WQSIZ);
 }

inbyte()  {
  while(ch==0) {
    if (eof) return 0;
    preprocess();
    }
  return gch();
  }

inline()
{
int	k;

while(1)
       {if(input2 == EOF)	/* no include file is open	*/
		{ if(duanefgets(line, LINEMAX, stdin) == NULL)
			eof=EOF;
		bump(0); return;
		}
	else	{ if(duanefgets(line, LINEMAX, input2)==NULL)
			{ fclose(input2);
			input2=EOF;
			}
		bump(0); return;
		}
	}
}
