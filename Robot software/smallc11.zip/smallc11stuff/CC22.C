extern int showcode;

ifline()  {
   while(1)  {
      inline();
	if(showcode)
	{
  	      printf("*%s\n",line);
	}
      if(eof) return;
      if(match("#ifdef"))  {
	 ++iflevel;
	 if(skiplevel) continue;
	 blanks();
	 if(findmac(lptr)==0)
	    skiplevel=iflevel;
	 continue;
	 }
      if(match("#ifndef"))  {
	 ++iflevel;
	 if(skiplevel) continue;
	 blanks();
	 if(findmac(lptr))
	    skiplevel=iflevel;
	 continue;
	 }
      if(match("#else"))  {
	 if(iflevel)  {
	    if(skiplevel==iflevel) skiplevel=0;
	    else if(skiplevel==0) skiplevel=iflevel;
	    }
	 else noiferr();
	 continue;
	 }
      if(match("#endif"))  {
	 if(iflevel)  {
	    if(skiplevel==iflevel) skiplevel=0;
	    --iflevel;
	    }
	 else noiferr();
	 continue;
	 }
      if(skiplevel) continue;
      if(listfp)  {
	 if(listfp==output) putchar(';');
	 printf("%s\n",line);
	 }
      if(ch==0) continue;
      break;
      }
   }

preprocess() {
  int k;
  char c;
  if(ccode) {
    line=mline;
    ifline();
/*  putchar('*');
    while(*line!= 0) putchar(*line++);
    putchar('\n');      */
    line=mline;
    if(eof) return;
    }
  else {
    line=pline;
    inline();
    return;
    }
  pptr = -1;
  while(ch) {
    if(white()) {
      keepch(' ');
      while(white()) gch();
      }
    else if(ch=='"') {
      keepch(ch);
      gch();
      while((ch!='"')|((*(lptr-1)==92)&(*(lptr-2)!=92))) {
	if(ch==0) {
	  error("no quote");
	  break;
	  }
	keepch(gch());
	}
      gch();
      keepch('"');
      }
    else if(ch==39) {
      keepch(39);
      gch();
      while((ch!=39)|((*(lptr-1)==92)&(*(lptr-2)!=92))) {
	if(ch==0) {
	  error("no apostrophe");
	  break;
	  }
	keepch(gch());
	}
      gch();
      keepch(39);
      }
    else if((ch=='/')&(nch=='*')) {
      bump(2);
      while(((ch=='*')&(nch=='/'))==0) {
	if(ch) bump(1);
	else {
	  ifline();
	  if(eof) break;
	  }
	}
      bump(2);
      }
    else if(an(ch)) {
      k=0;
      while(an(ch)) {
	if(k<NAMEMAX) msname[k++]=ch;
	gch();
	}
      msname[k]=0;
      if(k=findmac(msname)) while(c=macq[k++]) keepch(c);
      else {
	k=0;
	while(c=msname[k++]) keepch(c);
	}
      }
    else keepch(gch());
    }
  if(pptr>=LINEMAX) error("line too long");
  keepch(0);
  line=pline;
  bump(0);
  }

addmac() {
  int k;
  if(symname(msname, NO)==0) {
    illname();
    kill();
    return;
    }
  k=0;
  while(putmac(msname[k++]));
  while(white()) gch();
  while(putmac(gch()));
  if(macptr>=MACMAX) {
    printf("**** SMALL-C: macro string queue full ****\n");
    exit(-1);
    }
  }

putmac(c)  {
  macq[macptr]=c;
  if(macptr<MACMAX) ++macptr;
  return c;
  }

findmac(sname)	char *sname; {
mack=0;
while(mack<macptr)				/* mack is pointer into */
    { if(astreq(sname,macq+mack,NAMEMAX))	/* table of macros.	*/
	{ while(macq[mack++]);			/* while mack < macptr	*/
	return mack;				/* (end of table), search*/
	}
    while(macq[mack++]);
    while(macq[mack++]);
    }
return 0;
}
astreq(str1,str2,len)
char str1[],str2[];int len;
{
int k;

k=0;
while (k<len)
    { if ((str1[k])!=(str2[k]))break;
    /*	  ** must detect end of symbol table names terminated by
    ** symbol length in binary	  */
    if(str1[k] < ' ') break;
    if(str2[k] < ' ') break;
    ++k;
    }
if (an(str1[k]))return 0;
if (an(str2[k]))return 0;
return k;
}


setstage(before, start) int *before, *start; {
  if((*before=stagenext)==0) stagenext=stage;
  *start=stagenext;
  }

clearstage(before, start) char *before, *start; {
  *stagenext=0;
  if(stagenext=before) return;
  if(start) {
    printf("%s",start);
    }
  }

nextop(list) char *list; {
  char op[4];
  opindex=0;
  blanks();
  while(1) {
    opsize=0;
    while(*list > ' ') op[opsize++]= *list++;
    op[opsize]=0;
    if(opsize=streq(lptr, op))
      if((*(lptr+opsize) != '=')&
	 (*(lptr+opsize) != *(lptr+opsize-1)))
	 return 1;
    if(*list) {
      ++list;
      ++opindex;
      }
    else return 0;
    }
  }

