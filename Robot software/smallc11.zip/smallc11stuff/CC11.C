#include <ctype.h>	/* -hm */

/*	execution begins here		*/

 main(argc,argv)
 int	 argc,*argv;
 {
 reperr = NO;		/* no errors yet -hm */
 argcs=argc;
 argvs=argv;
 swend = (swnext = swq)+SWTABSZ-SWSIZ;
 stagelast = stage+STAGELIMIT;
 swactive=			/* not in switch	*/
 stagenext=			/* direct output mode	*/
 iflevel=			/* #if.. nesting = 0	*/
 skiplevel=		/* #if.. not encountered	*/
 macptr=		/* stack ptr (relative) 	*/
 csp=			/* clear the macro pool 	*/
 errflag=		/* not skipping errors till ";" */
 eof=			/* not eof yet			*/
 ncmp=			/* not in compount statement	*/
 files=
 filearg=
 quote[1] = 0;
 func1= 		 /* first function		 */
 ccode=1;		 /* enable preprocessing	 */
 wqptr=wq;		 /* clear while queue		 */
 quote[0]='"';           /* fake a quote literal         */
 input = input2 = EOF;
 fprintf(stderr,"\nSmall-C Compiler V. 2.0.2 for MC68HC11");
 fprintf(stderr,"\nCompiler Version: %s, %s\n",__DATE__,__TIME__);
 ask(); 		 /* get user options		 */
 openin();		 /* & initail input file	 */
 preprocess();		 /* fetch first line		 */
glbptr = STARTGLB;
glbflag = 1;
ctext = 0;
header();	/* intro code			*/
setops();	/* set values in op arrays	*/
parse();	/* process ALL input		*/
outside();	/* verify outside any function	*/
trailer();	/* follow up code		*/
fclose(output);
}
/*
** process all input text
**
** At this level, only static declarations,
**	defines, includes and function
**	definitions are legal...
*/
parse() {
  while (eof==0) {
    if(amatch("extern", 6))   dodeclare(EXTERNAL);
    else if(dodeclare(STATIC));
    else if(match("#asm"))    doasm();
    else if(match("#include"))doinclude();
    else if(match("#define")) addmac();
    else		      newfunc();
    blanks();	    /* force eof if pending */
    }
}

/*
** dump the literal pool
*/
dumplits(size) int size; {
  int j, k;
  k=0;
  while (k<litptr) {
    defstorage(size);
    j=10;
    while(j--) {
      outdec(getint(litq+k, size));
      k=k+size;
      if ((j==0)|(k>=litptr)) {
	nl();
	break;
	}
      outbyte(',');
      }
    }
  }
/*
** dump zeroes for default initial values
*/
dumpzero(size, count) int size, count; {
  int j;
  while (count > 0) {
    defstorage(size);
    j=30;
    while(j--) {
      outdec(0);
      if ((--count <= 0)|(j==0)) {
	nl();
	break;
	}
      outbyte(',');
      }
    }
  }
/*
** get run options
*/
ask()
{
	int i;

	listfp	= 0;
	nxtlab	= 0;
	output	= stdout;
	line	= mline;

	alarm	= NO;
	monitor	= NO;
	pause	= NO;
	showcode= NO;		/* do not show c-code in assembler file */

	i = 0;

	while((getarg(++i, line, LINESIZE, argcs, argvs)) != EOF)
	{
		if(line[0] != '-')
			continue;
		else
		{
			if(toupper(line[1]) == 'C') /* show c source code */
			{
				showcode = YES;
				continue;
			}
			if(toupper(line[1]) == 'M') /* show function headers */
			{
				monitor = YES;
				continue;
			}
                	if(toupper(line[1]) == 'B') /* begin label no */
			{
				nxtlab = atoi(&line[2]);
				continue;
			}
			else
			{
				usage();
			}
		}
	}
}

usage()
{
	fprintf(stderr,"\n usage: sc11 [-c] [-m] [-bxxxx] [<infile] [>outfile]");
	fprintf(stderr,"\n              -c = add c-source to output");
	fprintf(stderr,"\n              -m = monitor compiler work");
	fprintf(stderr,"\n              -b = set label start number\n");
	exit(1);
}


/*
** get next input file
*/
openin() {
  input=stdin;
  kill();
  }

setops() {
	int or(),xor(),and(),eq(),ne(),ule(),le(),uge(),ge();
	int ult(),lt(),ugt(),gt(),asr(),asl(),add(),sub(),mult();
	int div(),mod();
  op2[00]=     op[00]=	or;  /* heir5 */
  op2[01]=     op[01]= xor;  /* heir6 */
  op2[02]=     op[02]= and;  /* heir7 */
  op2[03]=     op[03]=	eq;  /* heir8 */
  op2[04]=     op[04]=	ne;
  op2[05]=ule; op[05]=	le;  /* heir9 */
  op2[06]=uge; op[06]=	ge;
  op2[07]=ult; op[07]=	lt;
  op2[ 8]=ugt; op[ 8]=	gt;
  op2[ 9]=     op[ 9]= asr;  /* heir10 */
  op2[10]=     op[10]= asl;
  op2[11]=     op[11]= add;  /* heir11 */
  op2[12]=     op[12]= sub;
  op2[13]=     op[13]=mult;  /* heir12 */
  op2[14]=     op[14]= div;
  op2[15]=     op[15]= mod;
  }

