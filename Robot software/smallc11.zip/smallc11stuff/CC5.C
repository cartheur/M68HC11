#include <stdio.h>
#include "ccdef.c"

extern	int	eof;

/*
*	Small C ver. 2.0 wants gets to return a line without an
*	end of line marker.  MSDOS wants to return a CR.
*	Also this dumb beast chokes on TABS!
*	SO... I trap out CR & LF and replace TAB with BLANK
*	(*&#^%^*!&^#%$@&*#&* compiler !!)
*/

#include <stdio.h>

duanefgets(str, max, fp)
char *str;
int max;
FILE *fp;
{
	int c;
	char *cs;

	cs = str;
	while((--max > 0) && (c = getc(fp)) != EOF)
	{
		if(( c == 0x0a ) || (c == 0x0d))
		{
			break;
		}
		else if (c == 0x09)
		{
			c = 0x20;
			*cs++ = c;
		}
		else
		{
			*cs++ = c;
		}
	}
	*cs = '\0';
	return((c == EOF && cs == str) ? NULL : str);
}

getarg(n, str, maxsz, argc, argv) int n; char *str; int maxsz, argc, *argv; {  char *dptr, *sptr; int cnt;
  if ((n>(argc-1))|(n<0)) {str[0] = NULL; return EOF;}
  cnt=0; dptr=str; sptr=argv[n];
  while(*dptr++ = *sptr++) {
    if(++cnt >= (maxsz-1))
      {*dptr=NULL; break;}
    }
  return cnt;
}

/************************ end of file cc5.c ******************************/