#include <ctype.h>
/*
** true if val1 -> int pointer or int array and val2 not ptr or array
*/
dbltest(val1,val2) int val1[], val2[]; {
  if(val1[2]!=CINT) return 0;
  if(val2[2]) return 0;
  return 1;
  }

/*
** determine type of binary operation
*/
result(lval, lval2) int lval[], lval2[]; {
  if((lval[2]!=0)&(lval2[2]!=0)) {
    lval[2]=0;
    }
  else if(lval2[2]) {
    lval[0]=lval2[0];
    lval[1]=lval2[1];
    lval[2]=lval2[2];
    }
  }

step(oper, lval) int (*oper)(), lval[]; {
  if(lval[1]) {
    if(lval[5]) {
      push();
      rvalue(lval);
      (*oper)(lval[2]>>2);
      pop();
      store(lval);
      return;
      }
    else {
      move();
      lval[5]=1;
      }
    }
  rvalue(lval);
  (*oper)(lval[2]>>2);
  store(lval);
  }

store(lval)  int lval[]; {
  if(lval[1]) putstk(lval);
  else	      putmem(lval);
  }

rvalue(lval) int lval[]; {
  if ((lval[0]!=0)&(lval[1]==0)) getmem(lval);
  else			       indirect(lval);
  }

test(label, parens)  int label, parens;  {
  int lval[8];
  int eq0(),ne0(),ult0(),le0(),lt0(),gt0(),ge0();
  char *before, *start;

  if(parens) needtoken("(");
  while(1) {
    setstage(&before, &start);
    if(heir1(lval)) rvalue(lval);
    if(match(",")) clearstage(before, start);
    else break;
    }
  if(parens) needtoken(")");
  if(lval[3]) {  /* constant expression */
    clearstage(before, 0);
    if(lval[4]) return;
    jump(label);
    return;
    }
  if(lval[7]) { 	/* stage address of "oper 0" code       */
    oper=lval[6];	/* operator function address		*/
    if((oper == op[EQ])|(oper == op2[ULE]))
			 zerojump(eq0, label, lval);
    else if((oper == op[NE])|(oper == op2[UGT]))
			 zerojump(ne0, label, lval);
    else if (oper == op[GT] )  zerojump(gt0, label, lval);
    else if (oper == op[GE] )  zerojump(ge0, label, lval);
    else if (oper == op2[UGE]) clearstage(lval[7],0);
    else if (oper == op[LT] )  zerojump(lt0, label, lval);
    else if (oper == op2[ULT]) zerojump(ult0, label, lval);
    else if (oper == op[LE] )  zerojump(le0, label, lval);
    else		 testjump(label);
    }
  else testjump(label);
  clearstage(before, start);
  }

constexpr(val) int *val; {
  int const1;
  char *before, *start;
  setstage(&before, &start);
  expression(&const1, val);
  clearstage(before, 0);  /* scratch generated code */
  if(const1==0) error("must be constant expression");
  return const1;
  }

const1(val) int val; {		/* this sucker generates		*/
  immed();			/* LDD #(val)				*/
  outdec(val);
  nl();
  }

const2(val) int val; {
  immed2();
  outdec(val);
  nl();
  }

constant(lval)	int lval[]; {
  lval=lval+3;
  *lval=1;	 /* assume it will be a constant */
  if (number(++lval)) immed();
  else if (pstr(lval)) immed();
  else if (qstr(lval)) {
    *(lval-1)=0; /* nope, it's a string address */
    immed();
    printlabel(litlab);
    outbyte('+');
    }
  else return 0;
  outdec(*lval);
  nl();
  return 1;
  }

number(val)  int val[]; {
  int k, minus;
  int hex;	/* -hm */
  k=minus=0;
  hex = 0;	/* -hm */

  while(1)
  {
    if(match("+"))	/* positive ?? */
	;
    else if(match("-"))	/* negative ?? */
	minus=1;
    else if(match("0x")) /* -hm */
	hex = 1;
    else if(match("0X")) /* -hm */
	hex = 1;
    else
	break;
  }
  if(hex)	/* -hm */
  {
	if(isxdigit(ch))
	{
		while(isxdigit(ch))
		{
			int tmp = inbyte();
			if((tmp >= '0') && (tmp <= '9'))
				tmp = tmp - '0';
			else if((tmp >= 'a') && (tmp <= 'f'))
				tmp = (tmp - 'a')+10;
			else if((tmp >= 'A') && (tmp <= 'F'))
				tmp = (tmp - 'A')+10;
			k=(k*16)+tmp;
		}
		val[0] = k;
		return 1;
	}
  }
  if(numeric(ch)==0)	/* char = numeric (0..9) ?? */
	return 0;	/* no, exit */
  while (numeric(ch))   /* yes, get input until not numeric */
	k=k*10+(inbyte()-'0');
  if (minus)
	k=(-k);
  val[0]=k;
  return 1;
  }

address(ptr) char *ptr; {
  immed();
  outstr(ptr+NAME);
  nl();
  }

pstr(val)  int val[]; {
  int k;
  k=0;
  if (match("'")==0) return 0;
  while(ch!=39)    k=(k&255)*256 + (litchar()&255);
  ++lptr;
  val[0]=k;
  return 1;
  }

qstr(val)  int val[]; {
  char c;
  if (match(quote)==0) return 0;
  val[0]=litptr;
  while (ch!='"') {
    if(ch==0) break;
    stowlit(litchar(), 1);
    }
  gch();
  litq[litptr++]=0;
  return 1;
  }

/*
** return current literal char & bump lptr
*/
litchar() {
  int i, oct;
  if((ch!=92)|(nch==0)) return gch();
  gch();
/*if(ch=='n') {gch(); return 13;}    CR */
  if(ch=='n') {gch(); return 10;} /* LF for UNIX */
  if(ch=='t') {gch(); return  9;} /* HT */
  if(ch=='b') {gch(); return  8;} /* BS */
  if(ch=='f') {gch(); return 12;} /* FF */
  i=3; oct=0;
  while(((i--)>0)&(ch>='0')&(ch<='7')) oct=(oct<<3)+gch()-'0';
  if(i==2) return gch(); else return oct;
  }

