/********************************************************
*	placed in SCCS file	Oct 29 86	Jrd	*
*	File = cc41.c					*
********************************************************/

#include <dos.h>

/*** print all assembler info before any code is generated*/

header()
{
struct date d;
struct time t;

getdate(&d);	/* MS-DOS / Turbo-C dependant !!!! */
gettime(&t);

printf("\n*******************************************************************\n");
printf("* SMALL-C Compiler V2.0.2                               Feb 15 1987\n");
printf("* Copyright 1982 J. E. Hendrix                                     \n");
printf("* Modified by Motorola for 68HC11                                  \n");
printf("* Modified by HCS to compile Compiler with Turbo-C 1.5             \n");
printf("* Compiler compiled on: %s, %s\n*\n",__DATE__,__TIME__);
printf("* 68HC11 Cross-Compile done on: %2.2d/%2.2d/%4d  %2.2d:%2.2d:%2.2d\n",d.da_mon,d.da_day,d.da_year,t.ti_hour,t.ti_min,t.ti_sec);
printf("*\n");
printf("*******************************************************************\n");
printf("*\n");
beglab=getlabel();
}

/*** print any assembler stuff needed at the end*/
trailer()  {

	extern int reperr;
	if(reperr == YES)
	{
		fprintf(stderr,"\n**** Errors in compile ****\n");
		exit(-1);
	}
	else
	{
		fprintf(stderr,"\n**** NO Errors in compile ****\n");
	}
}

/*** declare entry point*/
xentry() {
  outstr(ssname);
  ot("equ *");
  nl();
  }

/*
** declare external reference
*/
external(name) char *name; {
/*
ot("xref ");
outstr(name);
nl();
	*/
}

/*
** fetch object indirect to primary register
*/
indirect(lval) int lval[]; {
if(lval[1]==CCHAR)
	{
	ol("xgdx");
	ol("clra");
	ol("ldab 0,x");
	}
else	{
	ol("xgdx");
	ol("ldd 0,x");
	}
}

/*
** fetch a static memory cell into primary register
*/
getmem(lval)  int lval[];
{
  char *sym;
  sym=lval[0];
  if((sym[IDENT]!=POINTER)&(sym[TYPE]==CCHAR))
  {
    ol("clra");
    ot("ldab ");
  }
  else
  {
    ot("ldd ");
  }
  outstr(sym+NAME);
  nl();
}

/*
** fetch addr of the specified symbol into primary register
*/
getloc(sym)  char *sym; {
  const1(getint(sym+OFFSET, OFFSIZE)-csp);
ol("tsx");
ol("pshx");
ol("tsx");
ol("addd 0,x");
ol("pulx");
}

/*
** store primary register into static cell
*/
putmem(lval)  int lval[]; {
  char *sym;
  sym=lval[0];
  if((sym[IDENT]!=POINTER)&(sym[TYPE]==CCHAR)) {
    ot("stab ");
    }
  else ot("std ");
  outstr(sym+NAME);
  nl();
  }

/*
** put on the stack the type object in primary register
*/
putstk(lval) int lval[]; {
if(lval[1]==CCHAR) {
    ol("stab 0,x");
    }
  else ol("std 0,x");
  }

/*
** move primary register to secondary
*/
move() {
ol("pshb");
ol("psha");
ol("pulx");
  }

/*
** swap primary and secondary registers
*/
swap() {
ol("xgdx");
  }

/*** partial instruction to get immediate value
** into the primary register*/
immed() {
  ot("ldd #");
  }

/*
** partial instruction to get immediate operand
** into secondary register
*/
immed2() {
  ot("ldx #");
  }

/*** push primary register onto stack*/
push() {
ol("pshb");                  /* push registers */
ol("psha");
  csp=csp-BPW;
  }

/*** unpush or pop as required*/
smartpop(lval, start) int lval[]; char *start;
{
pop();
/*if(lval[5])  pop();
  else unpush(start);
	*/
  }


/*** pop stack to the secondary register*/
pop() {
  ol("pulx");
  csp=csp+BPW;
  }

/*** swap primary register and stack*/
swapstk() {
ol("puly");
ol("xgdy");
ol("pshy");
  }

/*** process switch statement*/
sw() {
call("ccswit");
  }

/*** call specified subroutine name*/
call(sname)  char *sname; {
  ot("jsr ");
  outstr(sname);
  nl();
  }

/*** return from subroutine*/
ret() {
  ol("rts");
  }

/*** perform subroutine call to value on stack*/
callstk() {
ol("pulx");
ol("jsr 0,x");
  csp=csp+BPW;
  }

/*** jump to internal label number*/
jump(label)  int label; {
  ot("jmp ");
  printlabel(label);
  nl();
  }

/*** test primary register and jump if false*/
testjump(label)  int label; {
  ol("cmpd #0");
  ol("bne *+5");
  ot("jmp ");
  printlabel(label);
  nl();
  }

/*** test primary register against zero and jump if false*/
/*	Mod 3/25/87 Test for false & jmp if condition
	is met	jrd	*/
zerojump(oper, label, lval) int oper, label, lval[]; {
  ol("cmpd #0");
  ol("bne *+5");
  ot("jmp ");
  printlabel(label);
  nl();
  }

/*** define storage according to size*/
defstorage(size) int size; {
  if(size==1) ot("fcb ");
  else	      ot("fdb ");
  }

/*** point to following object(s)*/
point() {
  ol("fdb $+2");
  }

/*** modify stack pointer to value given*/
modstk(newsp, save)  int newsp, save; {
  int k;
  k=newsp-csp;
  if(k==0)return newsp;
  if(k>=0) {
    if(k<12) {
      if(k&1) {
	ol("ins");
	k--;
	}
      while(k) {
	ol("pulx");
	k=k-BPW;
	}
      return newsp;
      }
    }
  if(k<0) {
    if(k>-7) {
      if(k&1) {
	ol("des");
	k++;
	}
      while(k) {
	ol("pshx");
	k=k+BPW;
	}
      return newsp;
      }
    }
  if(save) swap();
ol("tsx");
ol("pshx");
const1(k);
ol("tsx");
ol("addd 0,x");
ol("pulx");
ol("txs");
  if(save) swap();
  return newsp;
  }

/*** double primary register*/
doublereg()
{ ol("asld");
}
