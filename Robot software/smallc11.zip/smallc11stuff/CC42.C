/********************************************************
*	placed in SCCS file	Oct 29 86	Jrd	*
*	File = cc42.c					*
********************************************************/

/*** add primary and secondary registers (result in primary)*/
add() {
ol("pshx");
ol("tsx");
ol("addd 0,x");
ol("pulx");
}

/*** subtract primary from secondary register (result in primary)*/
sub() {
ol("xgdx");
ol("pshx");     ol("tsx");
ol("subd 0,x");
ol("pulx");
}

/*** multiply primary and secondary registers (result in primary)*/
mult() {call("ccmult");}

/*
** divide secondary by primary register
** (quotient in primary, remainder in secondary)
*/
div()
{

ol("xgdx");
ol("idiv");
ol("xgdx");
}

/*** remainder of secondary/primary
** (remainder in primary, quotient in secondary)*/
mod() {div();swap();}

/*
** inclusive "or" primary and secondary registers
** (result in primary)
*/
or()
{
call("ccor");
}

/*** exclusive "or" the primary and secondary registers
** (result in primary) */
xor() {
call("ccxor");
}

/*
** "and" primary and secondary registers
** (result in primary)
*/
and() {call("ccand");}

/*
** logical negation of primary register
*/
lneg() {
ol("coma"); ol("comb");
}

/*
** arithmetic shift right secondary register
** number of bits given in primary register
** (result in primary)
*/
asr() {call("ccasr");}

/*
** arithmetic shift left secondary register
** number of bits given in primary register
** (result in primary)
*/
asl() {call("ccasl");}

/*
** two's complement primary register
*/
neg() {
ol("coma"); ol("comb");
ol("addd #1");
}

/*
** one's complement primary register
*/
com() {
ol("coma"); ol("comb");
}

/*
** increment primary register by one object of whatever size
*/
inc(n) int n; {
  while(1) {
    ol("addd #1");
    if(--n < 1) break;
    }
  }

/*
** decrement primary register by one object of whatever size
*/
dec(n) int n; {
  while(1) {
    ol("subd #1");
    if(--n < 1) break;
    }
  }

/*** test for equal to*/
eq()  {call("cceq");}

/*** test for equal to zero*/
eq0(label) int label; {
  ol("cmpd #0");
  ol("beq *+5");
  ot("jmp ");
  printlabel(label);
  nl();
  }

/*** test for not equal to*/
ne()  {call("ccne");}

/*** test for not equal to zero*/
ne0(label) int label; {
ol("cpd #0");
ol("bne *+5");
ot("jmp ");
printlabel(label);
nl();
}

/*
** test for less than (signed)
*/
lt()  {call("cclt");}

/*
** test for less than to zero
*/
lt0(label) int label; {
ol("cpd #0");
ol("blt *+5");
ot("jmp ");
printlabel(label);
nl();
  }

/*
** test for less than or equal to (signed)
*/
le()  {call("ccle");}

/*
** test for less than or equal to zero
*/
le0(label) int label; {
ol("cpd #0");
ol("beq *+7");
ol("bmi *+5");
ot("jmp ");
printlabel(label);
nl();
  }

/*
** test for greater than (signed)
*/
gt()  {call("ccgt");}

/*
** test for greater than to zero
*/
gt0(label) int label; {
ol("cpd #0");
ol("bne *+5");
ot("jmp ");
printlabel(label);
nl();
ol("bpl *+5");
ot("jmp ");
printlabel(label);
nl();
}

/*
** test for greater than or equal to (signed)
*/
ge()  {call("ccge");}

/*
** test for gteater than or equal to zero
*/
ge0(label) int label; {
ol("cpd #0");
ol("bpl *+5");
ot("jmp ");
printlabel(label);
nl();
  }

/*
** test for less than (unsigned)
*/
ult()  {call("ccult");}

/*
** test for less than to zero (unsigned)
*/
ult0(label) int label; {
  ot("jmp ");
  printlabel(label);
  nl();
  }

/*
** test for less than or equal to (unsigned)
*/
ule()  {call("ccule");}

/*
** test for greater than (unsigned)
*/
ugt()  {call("ccugt");}

/*
** test for greater than or equal to (unsigned)
*/
uge()  {call("ccuge");}
