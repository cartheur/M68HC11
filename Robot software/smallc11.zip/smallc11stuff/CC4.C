/*
** Small-C Compiler Version 2.0
**
** Copyright 1982 J. E. Hendrix
**
** Part 4
*/
#include	<stdio.h>
#include	"ccdef.c"

/*** external references in part 1*/
extern char
 *stagenext, ssname[NAMESIZE];

extern int
  beglab,  csp, errflag, nxtlab;

extern FILE
 *output;

#include "cc41.c"
#include "cc42.c"
