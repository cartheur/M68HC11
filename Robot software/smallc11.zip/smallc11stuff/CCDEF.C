/*
** Small-C Compliler Version 2.0
**
** Copyright 1982 J. E. Hendrix
**
** Macro Definitions
*/

/*$NESTCMNT*/			/* allow nested comments	*/
/*$ZERO*/

#define YES	1
#define NO	0

/*** compile options*/

#define PHASE2			/* 2nd & later compiles 	*/
#define SEPARATE		/* compile separately		*/
#define NOCCARGC		/* no calls to CCARGC		*/
#define CMD_LINE		/* command line run options	*/
#define TAB		32	/* put out tabs of this value	*/

/*** machine dependent parameters*/

#define BPW	2		/* # of bytes per word		*/
#define LBPW	1
#define SBPC	1		/* stack bytes per character	*/
#define ERRCODE 7		/* op system return code	*/

/*** symbol table format*/

#define IDENT	 0
#define TYPE	 1
#define CLASS	 2
#define OFFSET	 3
#define NAME	 5
#define OFFSIZE (NAME-OFFSET)
#define SYMAVG	10
#define SYMMAX	14

/*** symbol table parameters*/

#define NUMLOCS   25
#define STARTLOC  symtab
#define ENDLOC	 (symtab+(NUMLOCS*SYMAVG))
#define NUMGLBS   180
#define STARTGLB  ENDLOC
#define ENDGLB	 (ENDLOC+((NUMGLBS-1)*SYMMAX))
#define SYMTBSZ   2770	/* NUMLOCS*SYMAVG + NUMGLBS*SYMMAX */

/*** System wide name size (for symbols)*/

#define NAMESIZE 9
#define NAMEMAX  8

/*** possible entries for "IDENT"*/

#define LABEL	 0
#define VARIABLE 1
#define ARRAY	 2
#define POINTER  3
#define FUNCTION 4

/*
** possible entries for "TYPE"
**    low order 2 bits make type unique within length
**    high order bits give length of object
*/
/*	LABEL	0 */

#define CCHAR	(1<<2)
#define CINT	(BPW<<2)

/*** possible entries for "CLASS"*/
/*	LABEL	  0 */

#define STATIC	  1
#define AUTOMATIC 2
#define EXTERNAL  3

/*** "switch" table*/

#ifdef PHASE2
#define SWSIZ	(2*BPW)
#define SWTABSZ (150*SWSIZ)	/* changed from 25*SWSIZ  -hm 22-06-88 */
#else
#define SWSIZ	 4
#define SWTABSZ 100
#endif

/*** "while" statement queue*/

#define WQTABSZ  30
#define WQSIZ	  3
#define WQMAX	(wq+WQTABSZ-WQSIZ)

/*** entry offsets in while queue*/

#define WQSP	0
#define WQLOOP	1
#define WQEXIT	2

/*** literal pool*/

#define LITABSZ 1500
#define LITMAX	(LITABSZ-1)

/*** input line*/

#define LINEMAX  128    /* from 80 to 128 -hm */
#define LINESIZE 129	/* from 81 to 129 -hm */

/*** output staging buffer size*/

#define STAGESIZE   800
#define STAGELIMIT  (STAGESIZE-1)

/*** macro (define) pool*/

#ifdef HASH
#define MACNBR	 90
#define MACNSIZE 990   /* 90*(NAMESIZE+2) */
#define MACNEND  (macn+MACNSIZE)
#define MACQSIZE 450   /* 90*5 */
#else
#define MACQSIZE 950
#endif
#define MACMAX	(MACQSIZE-1)

/*** statement types*/

#define STIF	  1
#define STWHILE   2
#define STRETURN  3
#define STBREAK   4
#define STCONT	  5
#define STASM	  6
#define STEXPR	  7
#define STDO	  8 /* compile "do" logic */
#define STFOR	  9 /* compile "for" logic */
#define STSWITCH 10 /* compile "switch/case/default" logic */
#define STCASE	 11
#define STDEF	 12

/*	equates for the operator array	*/

#define OR	0
#define XOR	1
#define AND	2
#define EQ	3
#define NE	4
#define ULE	5
#define LE	5
#define UGE	6
#define GE	6
#define ULT	7
#define LT	7
#define UGT	8
#define GT	8
#define ASR	9
#define ASL	10
#define ADD	11
#define SUB	12
#define MULT	13
#define DIV	14
#define MOD	15