/*
** Small-C Compiler Version 2.0
**
** Copyright 1982 J. E. Hendrix
**
** Part 2
*/
/*
** external references in part 1
*/

#include	<stdio.h>
#include	"ccdef.c"

extern char
  symtab[SYMTBSZ],
  stage[STAGESIZE],
  macq[MACQSIZE],
  pline[LINESIZE],
  mline[LINESIZE],
  alarm, *glbptr, *line, *lptr, *cptr, *cptr2,	*cptr3,
 *locptr, msname[NAMESIZE],  pause,  quote[2],
 *stagelast, *stagenext;

extern FILE
 *input,
 *input2,
 *output,
 *listfp;

extern int
  wq[WQTABSZ],
  mack,
  ccode,  ch,  csp,  eof,  errflag,  iflevel,
  macptr,  nch,
  nxtlab,  op[16],  opindex,  opsize,  pptr,
  skiplevel,  *wqptr;
extern int
  openin();

#include	"cc21.c"
#include	"cc22.c"

