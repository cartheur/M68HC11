#include	<stdio.h>
#include	"ccdef.c"

extern char
  symtab[SYMTBSZ],
  stage[STAGESIZE],
  macq[MACQSIZE],
  pline[LINESIZE],
  mline[LINESIZE],
  alarm, *glbptr, *line, *lptr, *cptr, *cptr2,	*cptr3,
 *locptr, msname[NAMESIZE],  pause,  quote[2],
 *stagelast, *stagenext;

extern int
ncmp,
  wq[WQTABSZ],
  ccode,  ch,  csp,  eof,  errflag,  iflevel,
  macptr,  nch,
  nxtlab,  op[16],  opindex,  opsize,  pptr,
  skiplevel,  *wqptr;

extern FILE
  *input,
  *input2,
  *output,
  *listfp;

illname()  {
   error("illegal symbol name");
   junk();
   }

multidef(sname)  char *sname;  {
   error("already defined");
   }

needlval()  {
   error("must be lvalue");
   }

/*
** force upper case alphabetics
*/
upper(c)  {
  if((c >= 'a') & (c <= 'z')) return (c - 32);
  else return c;
  }

/*
** return next avail internal label number
*/
getlabel() {
  return(++nxtlab);
  }

/*
** post a label in the program
*/
postlabel(label) int label; {
  printlabel(label);
  ot("equ *");
  nl();
  }

/*
** print specified number as a label
*/
printlabel(label)  int label; {
  outstr("cc");
  outdec(label);
  }

/*** test if given character is alphabetic*/
alpha(c) {
  return (((c>='a')&(c<='z'))|((c>='A')&(c<='Z'))|(c=='_'));
  }

/*** test if given character is numeric*/
numeric(c) {
  return((c>='0')&(c<='9'));
  }

/*
** test if given character is alphanumeric
*/
an(c)  {
  return ((alpha(c))|(numeric(c)));
  }

gch() {
  int c;
  if(c=ch) bump(1);
  return c;
  }

bump(n) int n; {
  if(n) lptr=lptr+n;
  else	lptr=line;
  if(ch=nch= *lptr) nch= *(lptr+1);
  }

kill() {
  *line=0;
  bump(0);
  }

keepch(c)  {
  if(pptr<LINEMAX) pline[++pptr]=c;
  }

noiferr() {
  error("no matching #if...");
  errflag=0;
  }

ol(ptr)  char ptr[];  {
  ot(ptr);
  nl();
  }

ot(ptr) char ptr[]; {
  outbyte(' ');
  outstr(ptr);
  }

outstr(ptr) char ptr[]; {
  /* must work with symbol table names terminated by length */
  while(*ptr >= ' ') outbyte(*ptr++);
  }

nl() {
  outbyte('\n');
  }

tab() {
  outbyte(' ');
  }

error(msg) char msg[]; {
  int handl;
  handl = fileno(stdout);	/* get handle */
  printf("%s\n",line);
  errout(msg, stdout);
  if(!isatty(handl))		/* avoid double error msg's to stdout */
  {
  	fprintf(stderr,"\n%s\n",line);
	errout(msg, stderr);
  }
}

errout(msg, fp) char msg[]; FILE *fp; {
  extern int reperr;
  int k; k=line+2;
  while(k++ <= lptr)
	fputc(' ',fp);
  fprintf(fp,"/\\\n");
  fprintf(fp,"**** ");
  fprintf(fp,"%s\n",msg);
  reperr = YES;
  }

outdec(number)	int number; {
  int k,zs;
  char c;
  zs = 0;
  k=10000;
  if (number<0) {
    number=(-number);
    outbyte('-');
    }
  while (k>=1) {
    c=number/k + '0';
    if ((c!='0')|(k==1)|(zs)) {
      zs=1;
      outbyte(c);
      }
    number=number%k;
    k=k/10;
    }
  }

streq(str1,str2)  char str1[],str2[]; {
  int k;
  k=0;
  while (str2[k]) {
    if ((str1[k])!=(str2[k])) return 0;
    ++k;
    }
  return k;
 }

match(lit)  char *lit; {
  int k;
  blanks();
  if (k=streq(lptr,lit)) {
    bump(k);
    return YES;
    }
  return NO;
  }

amatch(lit,len)  char *lit;int len; {
  int k;
  blanks();
  if (k=astreq(lptr,lit,len)) {
    bump(k);
    while(an(ch)) inbyte();
    return 1;
    }
  return 0;
 }

blanks() {
  while(1) {
    while(ch) {
      if(white()) gch();
      else return;
      }
    if(line==mline) return;
    preprocess();
    if(eof)break;
    }
  }

outbyte(c) {
  if(stagenext) {
    if(stagenext==stagelast) {
      error("staging buffer overflow");
      return 0;
      }
    else
    *stagenext++ = c;
    }
  else putchar(c);
  return c;
  }


/*
** verify compile ends outside any function
*/
outside()  {
  if (ncmp) error("no closing bracket");
  }

/*
** semicolon enforcer
**
** called whenever syntax requires a semicolon
*/
ns()  {
  if(match(";") == 0) error("no semicolon");
  else errflag = 0;
  }

white() {
  /* test for stack/program overlap */
  /* primary -> symname -> blanks -> white */
  if(*lptr==' ')   return 1;
  if(*lptr==TAB)   return 1;
  return 0;
  }
