
Active Registry Monitor (ARM): readme
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Please read this file carefully (especially the "Installation" chapter)
before installing the program to your computer.

IMPORTANT! If you obtained Active Registry Monitor not from our web page, but from
another source (CD or a software library), please visit our home page where
you might find a later version.


Contents
~~~~~~~~

 Program information
 Company information
 Description
 Installation (!)
 Registration
 Copyright and license
 Technical support


Program information
~~~~~~~~~~~~~~~~~~~

Program Archive Name:
 arm.zip
Program Name:
 Active Registry Monitor
Program Version:
 1.37
Program Release Date:
 June 4, 2003
Target OS:
 Windows 95, Windows 98, Windows ME, Windows NT, Windows 2000, XP
Brief Description:
 Utility designed for analysing the changes made in Windows Registry.
Software type:
 30-day trial


Company information
~~~~~~~~~~~~~~~~~~~

Company Name:
  SmartLine, Inc.
Author Name:
  Vadim Chumachenko
Contact E-mail Address:
  support@protect-me.com
  sales@protect-me.com
Contact WWW URL:
  http://www.ntutility.com


Description
~~~~~~~~~~~

Active Registry Monitor (ARM) is an utility designed for analysing the changes made 
to Windows Registry - by making the "snapshots" of it and keeping them in the browsable database. 
You can compare any two snapshots and get the list of keys/data which are new, deleted or just changed. 
ARM can do comparing not only in the entire Regisrty, but also in any key of the Registry. 
It is also possible to exclude any keys of the Registry from compare results. 
Moreover, you can create undo/redo files (for example, to rollback the changes). 
To view the current state of a key, or to modify it, you can use Jump to Regedit function. 
Contents of any key can be exported to *.reg file.

Very useful for detecting trojan viruses and elimination some problems caused by software and 
hardware install/uninstall.

Unlike Registry monitoring software (such as RegMon and Win-Expose Registry), and most uninstallers 
(CleenSweep, Uninstall, etc.), ARM compares full copies of the Registry made at different times, 
while the software mantioned above just monitors all accesses to the Registry in real time. 
So, our method allows to track all the changes, and doesn't affect the system performance.


Here is a brief list of ART features: 

- Scan different copies Registry into a special file and browse/search them "off-line"

- Scan the Registry on a remote computer

- Compare different copies of the Registry

- Compare individual branches of different copies of the Registry

- Undo and Redo Registry changes based on comparison results: directly from the program or by generating the REG-files

- Save any key of the Registry into the REG-file

- Fast search in Keys, Values and Data

- Bookmarks

- Opening selected key in the RegEdit

- Optional command-line interface for automated Registry scanning

- Convenient navigation between corresponding keys of different Registry copies and comparison results

- Adding comments to each copy of the Registry scanned

- Full insatll / uninstall support


Installation
~~~~~~~~~~~~

Run "setup.exe". You'll need to select the target directory for the install.

If you want to install Active Registry Monitor without user intervention run
Active Registry Monitor Setup with the /s parameter (e.g. "c:\setup.exe /s"). This
gives an install that can be used from within a batch file. There is a
special configuration file for silent setup: setup.ini. With this file, you
can customize the Active Registry Monitor installation parameters. For example:

1. "Install" parameters:

    Service   - Service and its related files will be installed
    Manager   - Manager and its related files will be installed
    Documents - documentation (readme.txt, register.txt) will be installed

    To specify a destination directory for Active Registry Monitor, you can supply the
    parameter InstallDir

    If you have the registration key-file for Active Registry Monitor, you can specify a
    directory with this file in the parameter RegFileDir

2. "Misc" parameters:

    Run - this parameter is used to launch an application or execute a batch
          file after a successful install.



Registration
~~~~~~~~~~~~

See "register.txt" file.


Copyright and license
~~~~~~~~~~~~~~~~~~~~~

See "license.txt" file.


Technical support
~~~~~~~~~~~~~~~~~

See "contacts.txt" file.


                                         Copyright(c) 2001-2003 SmartLine Inc.
                                                          All rights reserved.
                        Active Registry Monitor is trademark of SmartLine Inc.